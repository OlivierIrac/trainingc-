/*
 * Hello.hpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_HELLO_HPP_
#define SRC_HELLO_HPP_

#include <string>

class Hello {
public:
	Hello();
	virtual ~Hello();

	std::string sayHello();
};

#endif /* SRC_HELLO_HPP_ */
